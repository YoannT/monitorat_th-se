/**
	* @author J\u00e9r\u00e9my LIN | Chang Yeong HWANG
*/
public class ClassementException extends Exception{
  public ClassementException(String s){
    super(s);
  }
}
