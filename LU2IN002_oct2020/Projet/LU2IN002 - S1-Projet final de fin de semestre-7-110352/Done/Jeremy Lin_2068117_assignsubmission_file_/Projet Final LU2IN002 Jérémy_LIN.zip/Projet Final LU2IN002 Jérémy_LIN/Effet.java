/**
	* @author J\u00e9r\u00e9my LIN | Chang Yeong HWANG
*/
public interface Effet{
  //Effets pour les pro
  public boolean lift();
  public boolean smash();
  public boolean coupe();
}
