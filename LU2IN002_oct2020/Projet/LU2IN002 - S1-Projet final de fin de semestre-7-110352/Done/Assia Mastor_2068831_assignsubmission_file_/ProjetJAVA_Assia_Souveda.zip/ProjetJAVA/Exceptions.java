public class Exceptions extends Exception{


	public Exceptions(String message){

		super(message);
	}

}
