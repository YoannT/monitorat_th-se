
public class Arbitre extends Personne {

private int numeroarbitre;


public Arbitre(String nom,int age,int numeroarbitre){
super(nom,age);
this.numeroarbitre=numeroarbitre;
}
public String toString(){
	return "Il y a une faute";
}


}

