
public interface analyse {
public Joueur ennemienvue(Joueur jqdlb, Joueur joueurt[],int distancemax,Balle balle);
public Joueur yatilquelqun( Joueur jlpp,Joueur joueurt[],int distancemax);
public double distanceentrejoueurs(Joueur a, Joueur b);
public double distance(Balle balle, Joueur j);
}

