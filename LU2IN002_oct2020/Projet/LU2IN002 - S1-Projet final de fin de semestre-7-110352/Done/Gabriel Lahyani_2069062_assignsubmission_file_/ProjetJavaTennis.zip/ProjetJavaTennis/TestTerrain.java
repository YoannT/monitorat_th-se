public class TestTerrain{
    public static void main(String[] args){
        Terrain t1=new Terrain();

    }
}