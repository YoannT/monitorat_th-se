public class ManageScoreTest{
    public static void main(String[] args){

    }
}