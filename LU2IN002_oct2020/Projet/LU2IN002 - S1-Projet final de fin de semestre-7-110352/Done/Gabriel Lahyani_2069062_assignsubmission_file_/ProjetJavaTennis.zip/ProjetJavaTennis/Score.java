public class Score{
    int points;
    int jeu;
    int set;
    boolean advantage;
    int tiebreak;

    public Score(){
        advantage=false;

    }


}