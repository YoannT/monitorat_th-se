public class TestJoueur{
    public static void main(String[] args){
        int i;
        Personne j1=Joueur.choixJoueur();
        System.out.println(j1.getXp());



    }
}