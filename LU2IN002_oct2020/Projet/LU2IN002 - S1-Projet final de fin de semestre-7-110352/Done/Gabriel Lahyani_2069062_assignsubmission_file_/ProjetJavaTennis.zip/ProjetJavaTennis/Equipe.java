public class Equipe{
    String pays;
    String 
    public Equipe(){

    }
}