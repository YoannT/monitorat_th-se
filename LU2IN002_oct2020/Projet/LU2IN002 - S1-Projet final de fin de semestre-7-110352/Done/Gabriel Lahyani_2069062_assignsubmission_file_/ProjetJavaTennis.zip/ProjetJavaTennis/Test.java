import java.lang.Math;
public class Test{
    public static void main(String[] args){
        int []res={0,1};
        for(int i=0;i<20;i++) {
            int r=(int)(Math.random()*(2));
            System.out.println(r);
        }
    }
}