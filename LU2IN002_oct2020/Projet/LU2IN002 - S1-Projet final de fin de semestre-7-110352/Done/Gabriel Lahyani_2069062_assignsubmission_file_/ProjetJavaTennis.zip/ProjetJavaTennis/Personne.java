public abstract class  Personne{


    public abstract String getName();
    public abstract void presentation(int i);
    public abstract void presentation();
    public abstract int getXp();
    public abstract boolean getService();
    public abstract boolean Haveball();





}