public interface Actions{

  public boolean passe(Joueur j);

  public boolean tir();
}
