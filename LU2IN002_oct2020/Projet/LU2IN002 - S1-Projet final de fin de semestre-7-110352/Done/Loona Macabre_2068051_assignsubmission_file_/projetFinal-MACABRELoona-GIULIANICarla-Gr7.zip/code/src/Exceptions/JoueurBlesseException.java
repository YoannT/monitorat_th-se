package Exceptions;

public class JoueurBlesseException extends Exception {
    public JoueurBlesseException(String message){
        super(message);
    }
}
