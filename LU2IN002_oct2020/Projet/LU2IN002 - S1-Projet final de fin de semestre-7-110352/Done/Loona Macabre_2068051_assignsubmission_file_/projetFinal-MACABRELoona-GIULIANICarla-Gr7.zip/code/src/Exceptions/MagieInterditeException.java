package Exceptions;

public class MagieInterditeException extends Exception {
    public MagieInterditeException(String message){
        super(message);
    }
}
